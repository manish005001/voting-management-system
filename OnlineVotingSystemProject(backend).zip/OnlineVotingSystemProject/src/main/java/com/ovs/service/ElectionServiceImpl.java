package com.ovs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ovs.dao.Election;
import com.ovs.dto.CandidateResultDTO;
import com.ovs.repository.ElectionRepository;
import com.ovs.repository.VoteRepository;

@Service
public class ElectionServiceImpl implements ElectionService {

	@Autowired
	private ElectionRepository electionRepository;
	
	@Autowired
	private VoteRepository voteRepository;
	
	@Override
	public Election createElection(Election election) {
		election.setIsActive(true);
		return electionRepository.save(election);
	}

	@Override
	public List<Election> getAllElections() {
		return electionRepository.findAll();
	}

	@Override
	public Optional<Election> getElectionById(Long id) {
		return electionRepository.findById(id);
	}

	
	
	
}
