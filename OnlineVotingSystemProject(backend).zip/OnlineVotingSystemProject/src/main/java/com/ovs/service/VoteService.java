package com.ovs.service;

public interface VoteService {

	String castVote(Long userId, Long candidateId, Long electionId);

}
