package com.ovs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ovs.dao.Candidate;
import com.ovs.dao.Election;
import com.ovs.dao.User;
import com.ovs.repository.CandidateRepository;
import com.ovs.repository.ElectionRepository;
import com.ovs.repository.UserRepository;

@Service
public class CandidateServiceImpl implements CandidateService {
	
	 @Autowired
	 private CandidateRepository candidateRepository;

	 @Autowired
	 private ElectionRepository electionRepository;
	 
	 @Autowired
	 private UserRepository userRepository;

	@Override
	public Candidate addCandidateToElection(Long electionId, Long userId, Candidate candidate) {
		User user = userRepository.findById(userId)
		        .orElseThrow(() -> new RuntimeException("User not found"));
		Election election = electionRepository.findById(electionId)
                .orElseThrow(() -> new RuntimeException("Election not found"));
		
		candidate.setUser(user);
        candidate.setElection(election);
        candidate.setVoteCount(0);
        List<Candidate> list = election.getCandidates();
        list.add(candidate);
        election.setCandidates(list);
        return candidateRepository.save(candidate);
	}

	@Override
	public List<Candidate> getCandidatesByElection(Long electionId) {
		 return candidateRepository.findByElectionId(electionId);
	}

}
