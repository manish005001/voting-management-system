package com.ovs.service;

import java.util.List;

import com.ovs.dao.Candidate;

public interface CandidateService {

	Candidate addCandidateToElection(Long electionId, Long userId, Candidate candidate);

	List<Candidate> getCandidatesByElection(Long electionId);

}
