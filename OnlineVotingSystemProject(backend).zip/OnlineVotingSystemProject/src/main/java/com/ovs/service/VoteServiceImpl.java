package com.ovs.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ovs.dao.Candidate;
import com.ovs.dao.Election;
import com.ovs.dao.User;
import com.ovs.dao.Vote;
import com.ovs.repository.CandidateRepository;
import com.ovs.repository.ElectionRepository;
import com.ovs.repository.UserRepository;
import com.ovs.repository.VoteRepository;

@Service
public class VoteServiceImpl implements VoteService {
	
	@Autowired
    private VoteRepository voteRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private ElectionRepository electionRepository;

	@Override
	public String castVote(Long userId, Long candidateId, Long electionId) {
		if (voteRepository.existsByUserIdAndElectionId(userId, electionId)) {
            return "User has already voted in this election.";
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new RuntimeException("Candidate not found"));

        Election election = electionRepository.findById(electionId)
                .orElseThrow(() -> new RuntimeException("Election not found"));

        Vote vote = new Vote();
        vote.setUser(user);
        vote.setCandidate(candidate);
        vote.setElection(election);
        vote.setVoteTime(LocalDateTime.now());

        candidate.setVoteCount(candidate.getVoteCount() + 1);
        candidateRepository.save(candidate);
        voteRepository.save(vote);

        return "Vote cast successfully!";
	}

}
