package com.ovs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ovs.dao.Election;
import com.ovs.repository.ElectionRepository;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class ElectionScheduler {

    @Autowired
    private ElectionRepository electionRepository;

    // Runs every 1 minute
    @Scheduled(fixedRate = 60000)
    public void autoEndElections() {
        List<Election> elections = electionRepository.findAll();
        LocalDateTime now = LocalDateTime.now();

        for (Election election : elections) {
            if (Boolean.TRUE.equals(election.getIsActive()) && now.isAfter(election.getEndTime())) {
                election.setIsActive(false);
                electionRepository.save(election);
                System.out.println("Election ID " + election.getId() + " ended automatically.");
            }
        }
    }
}

