package com.ovs.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ovs.dao.Role;
import com.ovs.dao.User;
import com.ovs.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	private static final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

	@Override
	public User registerUser(@Valid User user) {
		Optional<User> existing = userRepository.findByEmail(user.getEmail());
        if (existing.isPresent()) {
            throw new RuntimeException("User with this email already exists.");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
     // Only set default if role is not provided
        if (user.getRole() == null) {
            user.setRole(Role.USER);
        }
        return userRepository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	public User loginUser(String email, String password) {
		 Optional<User> optionalUser = userRepository.findByEmail(email);

	        if (optionalUser.isEmpty()) {
	            throw new RuntimeException("Invalid email or password");
	        }

	        User user = optionalUser.get();

	        if (!passwordEncoder.matches(password, user.getPassword())) {
	            throw new RuntimeException("Invalid email or password");
	        }

	        return user;
	}
	
}
