package com.ovs.service;

import java.util.List;
import java.util.Optional;

import com.ovs.dao.Election;
import com.ovs.dto.CandidateResultDTO;

public interface ElectionService {

	Election createElection(Election election);

	List<Election> getAllElections();

	Optional<Election> getElectionById(Long id);


}
