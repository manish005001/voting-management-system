package com.ovs.service;

import java.util.List;

import javax.validation.Valid;

import com.ovs.dao.User;

public interface UserService {

	User registerUser(@Valid User user);

	List<User> getAllUsers();

	User loginUser(String email, String password);

}
