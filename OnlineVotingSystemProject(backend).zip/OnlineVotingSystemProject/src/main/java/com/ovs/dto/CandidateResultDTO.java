package com.ovs.dto;

public class CandidateResultDTO {
    private String candidateName;
    private Long voteCount;

    public CandidateResultDTO(String candidateName, Long voteCount) {
        this.candidateName = candidateName;
        this.voteCount = voteCount;
    }

	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public Long getVoteCount() {
		return voteCount;
	}

	public void setVoteCount(Long voteCount) {
		this.voteCount = voteCount;
	}

    
}
