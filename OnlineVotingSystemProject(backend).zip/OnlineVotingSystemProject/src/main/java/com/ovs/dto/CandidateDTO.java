package com.ovs.dto;

public class CandidateDTO {
	
}
