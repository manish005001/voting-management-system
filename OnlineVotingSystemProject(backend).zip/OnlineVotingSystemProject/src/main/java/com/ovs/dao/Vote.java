package com.ovs.dao;

import java.time.LocalDateTime;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Vote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "candidate_id", nullable = false)
    @JsonIgnore
    private Candidate candidate;

    @ManyToOne
    @JoinColumn(name = "election_id", nullable = false)
    @JsonIgnore
    private Election election;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    @NotNull(message = "Vote time cannot be null")
    private LocalDateTime voteTime;

	public Vote() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vote(Candidate candidate, Election election) {
		super();
		this.candidate = candidate;
		this.election = election;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Candidate getCandidate() {
		return candidate;
	}

	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}

	public Election getElection() {
		return election;
	}

	public void setElection(Election election) {
		this.election = election;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public LocalDateTime getVoteTime() {
		return voteTime;
	}

	public void setVoteTime(LocalDateTime localDateTime) {
		this.voteTime = localDateTime;
	}

	@Override
	public String toString() {
		return "Vote [id=" + id + ", candidate=" + candidate + ", election=" + election + ", user=" + user
				+ ", voteTime=" + voteTime + "]";
	}

    
}
