package com.ovs.dao;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Candidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Candidate name cannot be null")
    @Size(min = 2, max = 100, message = "Candidate name must be between 2 and 100 characters")
    private String name;

    @ManyToOne
    @JoinColumn(name = "election_id", nullable = false)
    @JsonIgnore
    private Election election;

    private int voteCount;  // To track the number of votes for this candidate
    
    @ManyToOne(optional = false)
    @JoinColumn(name = "user_id")
    @JsonIgnore
    private User user;


	public Candidate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Candidate(
			@NotNull(message = "Candidate name cannot be null") @Size(min = 2, max = 100, message = "Candidate name must be between 2 and 100 characters") String name,
			Election election) {
		super();
		this.name = name;
		this.election = election;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Election getElection() {
		return election;
	}

	public void setElection(Election election) {
		this.election = election;
	}

	public int getVoteCount() {
		return voteCount;
	}

	public void setVoteCount(int voteCount) {
		this.voteCount = voteCount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Candidate [id=" + id + ", name=" + name + ", election=" + election + ", voteCount=" + voteCount + "]";
	}

    
}
