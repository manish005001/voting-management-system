package com.ovs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class OnlineVotingSystemProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineVotingSystemProjectApplication.class, args);
	}

}
