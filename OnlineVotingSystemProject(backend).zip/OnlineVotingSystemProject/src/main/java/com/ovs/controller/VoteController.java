package com.ovs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ovs.service.VoteService;

@RestController
public class VoteController {

	@Autowired
	private VoteService voteService;
	
	@PostMapping("/cast-vote")
	public String castVote(@RequestParam Long userId, @RequestParam Long candidateId, @RequestParam Long electionId) {
		return voteService.castVote(userId, candidateId, electionId);
	}
}
