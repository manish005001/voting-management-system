package com.ovs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ovs.dao.Candidate;
import com.ovs.service.CandidateService;

@RestController
@RequestMapping("/api/candidates")
public class CandidateController {

    @Autowired
    private CandidateService candidateService;

    @PostMapping("/add/{electionId}/{userId}")
    public Candidate addCandidate(@PathVariable Long electionId,@PathVariable Long userId, @RequestBody Candidate candidate) {
        return candidateService.addCandidateToElection(electionId, userId, candidate);
    }

    @GetMapping("/election/{electionId}")
    public List<Candidate> getCandidates(@PathVariable Long electionId) {
        return candidateService.getCandidatesByElection(electionId);
    }
}