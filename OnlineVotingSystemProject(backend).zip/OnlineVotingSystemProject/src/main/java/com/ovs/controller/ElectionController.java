package com.ovs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ovs.dao.Election;
import com.ovs.dto.CandidateResultDTO;
import com.ovs.service.ElectionService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/election")
public class ElectionController {
	@Autowired
	private ElectionService electionService;
	
	@PostMapping("/create-election")
	public ResponseEntity<?> createElection(@RequestBody Election election) {
		if (election.getStartTime().isAfter(election.getEndTime())) {
	        return ResponseEntity.badRequest().body("Start time must be before end time.");
	    }
		
		Election created = electionService.createElection(election);
		return ResponseEntity.status(HttpStatus.CREATED).body(created);
	}
	
	@GetMapping("/get-elections")
	public List<Election> getAllElections() {
		return electionService.getAllElections();
	}
	
	@GetMapping("/get-election/{id}")
	public Election getElectionById(@PathVariable Long id) {
		return electionService.getElectionById(id).get();	
	}
	
}
